

const Editor = () => {
    return(
     <div>

     </div>
    )
}

export default Editor;