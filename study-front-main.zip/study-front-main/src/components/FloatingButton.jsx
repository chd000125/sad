import React from 'react';
import "../style/FloatingButton.css";

function FloatingButton() {
    return (
        <div className="floating-button">
            Study-Log
        </div>
    );
}

export default FloatingButton;